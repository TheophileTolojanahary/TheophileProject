import React, { useState } from 'react';
import { NavLink, Routes, Route } from 'react-router-dom';
import { FaBars, FaHome, FaTrash, FaMapMarkerAlt } from "react-icons/fa";
import '../style/SidebarCollecteur.css';  
import AccueilCollecteur from './AccueilCollecteur.jsx';
import GestionBacCollecteur from './GestionBacCollecteur.jsx';
import MapCollecteur from './MapCollecteur.jsx';

const SidebarCollecteur = () => {
    const [isOpen, setIsOpen] = useState(true);
    const toggle = () => setIsOpen(!isOpen);

    const menuItem = [
        { path: "accueilCollecteur", name: "Accueil ", icon: <FaHome /> },
        { path: "gestionBacCollecteur", name: "Gestion du Bac ", icon: <FaTrash /> },
        { path: "mapCollecteur", name: "Map ", icon: <FaMapMarkerAlt /> },
    ];

    return (
        <div className="CSSintCltr-sidebar-container">
            <div className={`CSSintCltr-sidebar ${isOpen ? '' : 'CSSintCltr-closed'}`}>
                <div className="CSSintCltr-top-section">
                    <h1 className={`CSSintCltr-logo ${isOpen ? '' : 'CSSintCltr-closed'}`}>Bacs info</h1>
                    <div className={`CSSintCltr-bars ${isOpen ? '' : 'CSSintCltr-closed'}`} onClick={toggle}>
                        <FaBars />
                    </div>
                </div>
                {menuItem.map((item, index) => (
                    <NavLink
                        to={item.path}
                        key={index}
                        className={({ isActive }) => `CSSintCltr-link ${isActive ? 'CSSintCltr-active' : ''}`}
                    >
                        <div className="CSSintCltr-icon">{item.icon}</div>
                        <div className={`CSSintCltr-link-text ${isOpen ? '' : 'CSSintCltr-closed'}`}>{item.name}</div>
                    </NavLink>
                ))}
            </div>
            <main className={`CSSintCltr-main-content ${isOpen ? '' : 'CSSintCltr-closed'}`}>
                <Routes>
                    <Route path="accueilCollecteur" element={<AccueilCollecteur />} />
                    <Route path="gestionBacCollecteur" element={<GestionBacCollecteur />} />
                    <Route path="mapCollecteur" element={<MapCollecteur />} />
                </Routes>
            </main>
        </div>
    );
};

export default SidebarCollecteur;
