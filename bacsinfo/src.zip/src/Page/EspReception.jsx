import React, { useEffect, useState } from 'react';
import '../style/EspReception.css';

const EspReception = () => {
  const [bacs, setBacs] = useState([]); // Stockage des données des bacs
  const [currentPage, setCurrentPage] = useState(0); // Page actuelle pour la pagination
  const itemsPerPage = 6; // Nombre de bacs affichés par page

  // Récupération des données des bacs depuis l'API
  useEffect(() => {
    const fetchBacs = async () => {
      try {
        const response = await fetch('http://localhost:8080/api/bacs/get'); // Adapter l'URL si nécessaire
        const data = await response.json();
        // Initialiser chaque bac avec un niveau par défaut de 0
        const bacsWithDefaultLevels = data.map(bac => ({ ...bac, niveau: 0 }));
        setBacs(bacsWithDefaultLevels);
      } catch (error) {
        console.error('Erreur lors de la récupération des données des bacs:', error);
      }
    };

    fetchBacs();
  }, []);

  // Gestion de la pagination
  const startIndex = currentPage * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const displayedBacs = bacs.slice(startIndex, endIndex);

  // Gestion de la navigation des pages
  const handlePrevPage = () => setCurrentPage((prevPage) => Math.max(prevPage - 1, 0));
  const handleNextPage = () => setCurrentPage((prevPage) => Math.min(prevPage + 1, Math.floor(bacs.length / itemsPerPage)));

  return (
    <div className="dashboard-container">
      <h2>Tableau de Bord des Niveaux de Bacs à Ordures</h2>
      
      {/* Boutons de pagination */}
      <div className="pagination-controls">
        <button onClick={handlePrevPage} disabled={currentPage === 0}>←</button>
        <button onClick={handleNextPage} disabled={endIndex >= bacs.length}>→</button>
      </div>
      
      {/* Affichage des niveaux de bacs */}
      <div className="bac-levels">
        {displayedBacs.map((bac, index) => (
          <div key={bac.id} className="bac">
            <div className="bac-gauge">
              <svg viewBox="0 0 36 36" className="circular-chart">
                <path
                  className="circle-bg"
                  d="M18 2.0845
                     a 15.9155 15.9155 0 0 1 0 31.831
                     a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className="circle"
                  strokeDasharray={`${bac.niveau}, 100`}
                  d="M18 2.0845
                     a 15.9155 15.9155 0 0 1 0 31.831
                     a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <div className="bac-percentage">
                {bac.niveau}%
              </div>
            </div>
            <div className="bac-info">
              <h4>Bac {bac.numBac}</h4>
              <p>Niveau: {bac.niveau}%</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EspReception;
