import React, { useState } from "react";
import { FaEye, FaEyeSlash } from "react-icons/fa";
import { Link, useNavigate } from "react-router-dom"; 
import axios from "axios"; 
import "../style/Login.css";
import logo from "../assets/logo.png";


const Login = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState(""); 
  const [isAdmin, setIsAdmin] = useState(false); 
  const [isCollector, setIsCollector] = useState(true); 
  const [isUser, setIsUser] = useState(false); 

  const navigate = useNavigate(); 

  const handleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    let apiEndpoint;

    // Sélectionnez l'API en fonction du rôle
    if (isAdmin) {
      apiEndpoint = "http://localhost:8080/api/admins/validate";
    } else if (isCollector) {
      apiEndpoint = "http://localhost:8080/api/collecteurs/validate";
    } else if (isUser) {
      apiEndpoint = "http://localhost:8080/api/utilisateurs/validate"; 
    }

    try {
      const response = await axios.get(apiEndpoint, {
        params: {
          nom: username,
          motDePasse: password,
        },
      });

      if (response.status === 200) {
        const redirectPath = isAdmin ? "/accueil" : isCollector ? "/interfaceCollecteur" : "/interfaceUtilisateur"; 
        navigate(redirectPath); 
      }
    } catch (error) {
      console.error("Erreur de connexion :", error);
      setErrorMessage("Nom d'utilisateur ou mot de passe incorrect."); 

      setTimeout(() => {
        setErrorMessage("");
      }, 5000);
    }
  };

  const handleRoleChange = (role) => {
    if (role === "admin") {
      setIsAdmin(true);
      setIsCollector(false);
      setIsUser(false); 
    } else if (role === "collector") {
      setIsAdmin(false);
      setIsCollector(true);
      setIsUser(false); 
    } else {
      setIsAdmin(false);
      setIsCollector(false);
      setIsUser(true); 
    }
  };

  return (
    <div className="loginCSS-container">
    

    <div class="container">
     <div className="logo-container">
        <img src={logo} alt="Logo" className="logo-image" />
      </div>
      <div className="loginCSS-form">
        <h2>Connexion</h2>
        <form onSubmit={handleSubmit}>
          {errorMessage && (
            <div className={`loginCSS-error-message ${!errorMessage ? 'hide' : ''}`}>
              {errorMessage}
            </div>
          )}
          <div className="loginCSS-form-group">
            <label htmlFor="username">Nom d'utilisateur :</label>
            <div className="loginCSS-input-wrapper">
              <input
                type="text"
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Entrez votre nom d'utilisateur"
                required 
              />
            </div>
          </div>
          <div className="loginCSS-form-group">
            <label htmlFor="password">Mot de passe :</label>
            <div className="loginCSS-input-wrapper">
              <input
                type={showPassword ? "text" : "password"}
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Entrez votre mot de passe"
                required 
              />
              <span className="loginCSS-show-password" onClick={handleShowPassword}>
                {showPassword ? <FaEyeSlash /> : <FaEye />}
              </span>
            </div>
          </div>
          <button type="submit">Connexion</button>
          <div className="loginCSS-role-toggle">
            <div className="role-option">
              <label>
                <input
                  type="radio"
                  checked={isCollector}
                  onChange={() => handleRoleChange("collector")}
                />
                Se connecter en tant que collecteur
              </label>
            </div>
            <div className="role-option">
              <label>
                <input
                  type="radio"
                  checked={isAdmin}
                  onChange={() => handleRoleChange("admin")}
                />
                Se connecter en tant qu'admin
              </label>
            </div>
            <div className="role-option">
              <label>
                <input
                  type="radio"
                  checked={isUser}
                  onChange={() => handleRoleChange("user")}
                />
                Se connecter en tant qu'utilisateur
              </label>
            </div>
          </div>
          <p>
            Mot de passe oublié ? <Link to="/forgot-password">Cliquez ici</Link>
          </p>
          <p>
            Vous n'avez pas encore de compte ?{" "}
            <Link to="/choixInscription">Inscrivez-vous</Link>
          </p>
        </form>
      </div>
    </div>
    </div>

  );
};

export default Login;
