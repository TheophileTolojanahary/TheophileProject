import React, { useState, useEffect } from "react";
import Calendar from "react-calendar";
import axios from "axios";
import "../style/historique.css";
import "react-calendar/dist/Calendar.css";

function Historique() {
  const [totalCollectes, setTotalCollectes] = useState(0);
  const [collectes, setCollectes] = useState([]);
  const [date, setDate] = useState(new Date());

  // Récupérer le nombre total de collectes
  const fetchTotalCollectes = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/collectes/countTotal");
      setTotalCollectes(response.data);
    } catch (error) {
      console.error("Erreur lors de la récupération du nombre total de collectes :", error);
    }
  };

  // Récupérer les collectes par date
  const fetchCollectesByDate = async (selectedDate) => {
    const formattedDate = selectedDate.toISOString().split('T')[0]; // Format de date YYYY-MM-DD
    try {
      const response = await axios.get(`http://localhost:8080/api/collectes/getByDate/${formattedDate}`);
      setCollectes(response.data);
    } catch (error) {
      console.error("Erreur lors de la récupération des collectes :", error);
    }
  };

  // Appels de l'API lors du montage du composant
  useEffect(() => {
    fetchTotalCollectes();
    fetchCollectesByDate(date); // Appel initial pour récupérer les collectes de la date actuelle
  }, []);

  // Mettre à jour les collectes lorsque la date change
  useEffect(() => {
    fetchCollectesByDate(date);
  }, [date]);

  // Fonction pour formater la date
  const formatDate = (date) => {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    return date.toLocaleDateString('fr-FR', options);
  };

  return (
    <div className="HQ-historique-dashboard">
      <header className="HQ-historique-header">
        <h1>Historique de collecte</h1>
      </header>
      <div className="HQ-historique-grid">
        <div className="HQ-historique-card">
          <div className="total-collectes">
            Nombre total de collectes faites : {totalCollectes}
          </div>
          <div className="HQ-historique-tableau-container">
            <table>
              <thead>
                <tr>
                  <th> Liste de Bac à ordures collecté</th>
                </tr>
              </thead>
              <tbody>
                {collectes.map((collecte) => (
                  <tr key={collecte.id}>
                    <td>{collecte.numBac}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="HQ-historique-card">
          <p>{formatDate(date)}</p>
          <Calendar onChange={setDate} value={date} />
        </div>
      </div>
    </div>
  );
}

export default Historique;
