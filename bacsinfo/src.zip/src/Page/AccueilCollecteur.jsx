
import React, { useState, useEffect } from 'react';
import '../style/AccueilCollecteur.css';
import { Line } from 'react-chartjs-2'; // Utilisation de chart.js pour le graphique
import 'chart.js/auto'; // Si vous utilisez Chart.js 3

const AccueilCollecteur = () => {
  // Données initiales pour les statistiques
  const [collecteurs, setCollecteurs] = useState(10); // Exemple statique
  const [bacsOrdures, setBacsOrdures] = useState(200);
  const [visiteurs, setVisiteurs] = useState(50);
  const [bacsCollectes, setBacsCollectes] = useState(150);
  const [bacsPlein, setBacsPlein] = useState(30);
  const [bacsVides, setBacsVides] = useState(170);
  const [dateHeure, setDateHeure] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setDateHeure(new Date());
    }, 1000); // Mise à jour de la date et l'heure chaque seconde
    return () => clearInterval(interval);
  }, []);

  // Données pour le graphique
  const data = {
    labels: ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi', 'Dimanche'],
    datasets: [
      {
        label: 'Bacs collectés par semaine',
        data: [30, 45, 60, 40, 55, 70, 80], // Données exemple
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
        borderWidth: 1,
      },
    ],
  };

  return (
    <div className="accueil-container">
      <h1>Système de Gestion de Collecte des Ordures du Village</h1>
      <div className="dashboard">
        <div className="stat-box">
          <h3>Nombre de Collecteurs</h3>
          <p>{collecteurs}</p>
        </div>
        <div className="stat-box">
          <h3>Nombre de Bacs à Ordures</h3>
          <p>{bacsOrdures}</p>
        </div>
        <div className="stat-box">
          <h3>Nombre de Visiteurs</h3>
          <p>{visiteurs}</p>
        </div>
        <div className="stat-box">
          <h3>Total Bacs Collectés</h3>
          <p>{bacsCollectes}</p>
        </div>
        <div className="stat-box">
          <h3>Bacs Pleins Actuels</h3>
          <p>{bacsPlein}</p>
        </div>
        <div className="stat-box">
          <h3>Bacs Vides Actuels</h3>
          <p>{bacsVides}</p>
        </div>
        <div className="stat-box">
          <h3>Date et Heure</h3>
          <p>{dateHeure.toLocaleDateString()} {dateHeure.toLocaleTimeString()}</p>
        </div>
      </div>

      <div className="historique">
        <h2>Calendrier de l'Historique de Collecte</h2>
        {/* Ajout du calendrier ici (par exemple react-calendar) */}
      </div>

      <div className="graph-section">
        <h2>Courbe Graphique de Collecte par Semaine</h2>
        <Line data={data} />
      </div>

      <div className="taux-section">
        <h2>Taux de Collecte par Semaine</h2>
        <p>80%</p> {/* Exemples de données */}
      </div>
    </div>
  );
};

export default AccueilCollecteur;
