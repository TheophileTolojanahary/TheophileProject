import React, { useState, useEffect } from 'react';
import { FaSave, FaUndo, FaPrint } from 'react-icons/fa';
import { useLocation } from 'react-router-dom';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import '../style/detaillebac.css'; // Importation du fichier CSS

function DetailleBac() {
  const location = useLocation();
  const { numeroBac, typeBac, longitude, latitude, niveau } = location.state || {};

  const [distance, setDistance] = useState('');
  const [positionActuelle, setPositionActuelle] = useState({ longitude: '', latitude: '' });
  const [bacDetails, setBacDetails] = useState({ numeroBac, typeBac, longitude, latitude, niveau });

  useEffect(() => {
    const getPosition = () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const { longitude, latitude } = position.coords;
            setPositionActuelle({ longitude, latitude });
            calculateDistance(latitude, longitude);
          },
          (error) => {
            console.error("Erreur de géolocalisation :", error);
            setPositionActuelle({ longitude: 'Non disponible', latitude: 'Non disponible' });
          }
        );
      } else {
        console.log("La géolocalisation n'est pas supportée par ce navigateur.");
      }
    };

    getPosition();
  }, [latitude, longitude]);

  const calculateDistance = (lat1, lon1) => {
    const R = 6371; // Rayon de la Terre en km
    const dLat = (lat1 - latitude) * (Math.PI / 180);
    const dLon = (lon1 - longitude) * (Math.PI / 180);

    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(latitude * (Math.PI / 180)) * Math.cos(lat1 * (Math.PI / 180)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
      
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distanceInKm = R * c; // Distance en km
    setDistance(distanceInKm.toFixed(2)); // Arrondi à 2 décimales
  };

  const handlePrint = () => {
    const printContent = document.getElementById('printableArea');
    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Impression</title>');
    printWindow.document.write('</head><body>');
    printWindow.document.write(printContent.innerHTML);
    printWindow.document.close();
    printWindow.print();
  };

  const handleReset = () => {
    setBacDetails({ numeroBac: '', typeBac: '', longitude: '', latitude: '', niveau: '' });
    setDistance('');
  };

  const handleSave = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('Détails du Bac', 14, 20);

    doc.setFontSize(12);
    doc.text(`Date et Heure: ${new Date().toLocaleString()}`, 14, 30);
    doc.text(`Ma position actuelle: Longitude: ${positionActuelle.longitude}, Latitude: ${positionActuelle.latitude}`, 14, 40);
    
    doc.text(`Numéro Bac: ${bacDetails.numeroBac}`, 14, 50);
    doc.text(`Longitude: ${bacDetails.longitude}`, 14, 60);
    doc.text(`Latitude: ${bacDetails.latitude}`, 14, 70);
    doc.text(`Type Bac: ${bacDetails.typeBac}`, 14, 80);
    doc.text(`Distance du bac: ${distance} km`, 14, 90);
    doc.text(`Niveau: ${bacDetails.niveau || '...'}`, 14, 100);

    doc.save('details_du_bac.pdf');
  };

  return (
    <div className="DetailleB-container0">
      <div className="DetailleB-container" id="printableArea">
        <div className="DetailleB-header">
          <div className="DetailleB-title">Détails du Bac</div>
          <div className="DetailleB-dateTime">Date et Heure: {new Date().toLocaleString()}</div>
        </div>

        <div style={{ marginBottom: '20px' }}>
          <label style={{ color: '#00796b', marginTop: '10px' }}>Ma position actuelle :</label>
          <input
            type="text"
            value={`Longitude: ${positionActuelle.longitude}, Latitude: ${positionActuelle.latitude}`}
            readOnly
            className="DetailleB-readOnlyInput"
          />
        </div>

        <div className="DetailleB-section">
          <div className="DetailleB-box">
            <h3 className="DetailleB-boxTitle">Informations du Bac</h3>
            <p className="DetailleB-boxText">Numéro Bac: {bacDetails.numeroBac}</p>
            <p className="DetailleB-boxText">Longitude: {bacDetails.longitude}</p>
            <p className="DetailleB-boxText">Latitude: {bacDetails.latitude}</p>
            <p className="DetailleB-boxText">Type Bac: {bacDetails.typeBac}</p>
            <label style={{ color: '#00796b', marginTop: '10px' }}>Distance du bac entre ma position actuelle :</label>
            <input
              type="text"
              value={`${distance} km`}
              readOnly
              className="DetailleB-readOnlyInput"
            />
          </div>
          <div className="DetailleB-box">
            <h3 className="DetailleB-boxTitle">Niveau de Bac</h3>
            <p className="DetailleB-boxText">Niveau: {bacDetails.niveau || '...'}</p>
            <p className="DetailleB-boxText">Capacité: ...</p>
            <p className="DetailleB-boxText">Remplissage: ...</p>
          </div>
        </div>

        <div className="DetailleB-footer">
          <div className="DetailleB-buttons">
            <button className="DetailleB-button" onClick={handleReset}><FaUndo className="DetailleB-buttonIcon" /> Réinitialiser</button>
            <button className="DetailleB-button" onClick={handlePrint}><FaPrint className="DetailleB-buttonIcon" /> Imprimer</button>
            <button className="DetailleB-button" onClick={handleSave}><FaSave className="DetailleB-buttonIcon" /> Enregistrer</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DetailleBac;
