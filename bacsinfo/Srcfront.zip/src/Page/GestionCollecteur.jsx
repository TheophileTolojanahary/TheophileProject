import React, { useState, useEffect } from "react";
import { FaTrash, FaPlus, FaEye, FaEyeSlash } from "react-icons/fa"; // Importer les icônes pour afficher/cacher le mot de passe
import axios from "axios";
import '../style/GestionCollecteur.css';

const GestionCollecteur = () => {
  const [nom, setNom] = useState("");
  const [prenom, setPrenom] = useState("");
  const [email, setEmail] = useState("");
  const [adresse, setAdresse] = useState("");
  const [numeroTelephone, setNumeroTelephone] = useState("");
  const [motDePasse, setMotDePasse] = useState("");
  const [showPassword, setShowPassword] = useState(false); // État pour afficher/cacher le mot de passe
  const [allCollecteursData, setAllCollecteursData] = useState([]);
  const [showNotification, setShowNotification] = useState(false);
  const [notificationData, setNotificationData] = useState({});
  const [deleteId, setDeleteId] = useState(null);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);

  const fetchCollecteurs = () => {
    axios
      .get("http://localhost:8080/api/collecteurs/get")
      .then((res) => {
        setAllCollecteursData(res.data);
      })
      .catch((err) => console.log(err));
  };

  useEffect(() => {
    fetchCollecteurs();
  }, []);

  const handleAddCollecteur = (e) => {
    e.preventDefault();
    const newCollecteur = {
      nom,
      prenom,
      email,
      adresse,
      numeroTelephone,
      motDePasse,
    };

    axios
      .post("http://localhost:8080/api/collecteurs/post", newCollecteur)
      .then((res) => {
        fetchCollecteurs();
        setShowNotification(true);
        setNotificationData(newCollecteur);

        setTimeout(() => {
          setShowNotification(false);
          setNom("");
          setPrenom("");
          setEmail("");
          setAdresse("");
          setNumeroTelephone("");
          setMotDePasse("");
        }, 5000);
      })
      .catch((err) => {
        console.log(err.response.status);
      });
  };

  const handleDelete = (id) => {
    setDeleteId(id);
    setShowDeleteConfirmation(true);
  };

  const confirmDelete = () => {
    axios
      .delete(`http://localhost:8080/api/collecteurs/delete/${deleteId}`)
      .then(() => {
        fetchCollecteurs();
        setShowDeleteConfirmation(false);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const cancelDelete = () => {
    setShowDeleteConfirmation(false);
    setDeleteId(null);
  };

  return (
    <div className="Clsnm-container">
      {showNotification && (
        <div className="Clsnm-notification">
          <strong>Notification:</strong> Nouveau collecteur ajouté : {notificationData.nom} {notificationData.prenom}
        </div>
      )}

      {showDeleteConfirmation && (
        <div className="Clsnm-delete-confirmation">
          <p>Êtes-vous sûr de vouloir supprimer ce collecteur ?</p>
          <button onClick={confirmDelete} className="Clsnm-confirm-button">Oui</button>
          <button onClick={cancelDelete} className="Clsnm-cancel-button">Non</button>
        </div>
      )}

      <form onSubmit={handleAddCollecteur}>
        <div className="Clsnm-form-group">
          <div className="Clsnm-input-group">
            <input
              className="Clsnm-input"
              type="text"
              value={nom}
              onChange={(e) => setNom(e.target.value)}
              placeholder="Nom"
              required
            />
          </div>
          <div className="Clsnm-input-group">
            <input
              className="Clsnm-input"
              type="text"
              value={prenom}
              onChange={(e) => setPrenom(e.target.value)}
              placeholder="Prénom"
              required
            />
          </div>
          <div className="Clsnm-input-group">
            <input
              className="Clsnm-input"
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              required
            />
          </div>
          <div className="Clsnm-input-group">
            <input
              className="Clsnm-input"
              type="text"
              value={adresse}
              onChange={(e) => setAdresse(e.target.value)}
              placeholder="Adresse"
              required
            />
          </div>
          <div className="Clsnm-input-group">
            <input
              className="Clsnm-input"
              type="text"
              value={numeroTelephone}
              onChange={(e) => setNumeroTelephone(e.target.value)}
              placeholder="Numéro de téléphone"
              required
            />
          </div>
          <div className="Clsnm-input-group">
            <div className="password-container">
              <input
                className="Clsnm-input"
                type={showPassword ? "text" : "password"} // Modifier le type selon l'état showPassword
                value={motDePasse}
                onChange={(e) => setMotDePasse(e.target.value)}
                placeholder="Mot de passe"
                required
              />
              <span 
                className="password-toggle" 
                onClick={() => setShowPassword(!showPassword)} // Changer l'état au clic
              >
                {showPassword ? <FaEyeSlash /> : <FaEye />} {/* Afficher l'icône correspondante */}
              </span>
            </div>
          </div>
          <button className="Clsnm-button" type="submit">
            <FaPlus /> Ajouter
          </button>
        </div>
      </form>

      <table className="Clsnm-table">
        <thead>
          <tr>
            <th className="Clsnm-th">Nom</th>
            <th className="Clsnm-th">Prénom</th>
            <th className="Clsnm-th">Email</th>
            <th className="Clsnm-th">Adresse</th>
            <th className="Clsnm-th">Numéro de téléphone</th>
            <th className="Clsnm-th">Actions</th>
          </tr>
        </thead>
        <tbody>
          {allCollecteursData.map((collecteur) => (
            <tr key={collecteur.id}>
              <td className="Clsnm-td">{collecteur.nom}</td>
              <td className="Clsnm-td">{collecteur.prenom}</td>
              <td className="Clsnm-td">{collecteur.email}</td>
              <td className="Clsnm-td">{collecteur.adresse}</td>
              <td className="Clsnm-td">{collecteur.numeroTelephone}</td>
              <td className="Clsnm-td">
                <button onClick={() => handleDelete(collecteur.id)}>
                  <FaTrash />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default GestionCollecteur;
