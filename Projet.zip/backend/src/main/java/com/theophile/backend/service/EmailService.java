package com.theophile.backend.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import jakarta.activation.DataSource;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import jakarta.mail.util.ByteArrayDataSource;

import org.springframework.beans.factory.annotation.Value;

public class EmailService {
    @Value("${spring.mail.username}")
    private String fromEmail;
    private final JavaMailSender javaMailSender;

    @Autowired
    public EmailService(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    public void sendEmail(String to, String subject, String text) throws MessagingException {
        MimeMessage message = javaMailSender.createMimeMessage();// creare MIME =Multipurpose Internet Mail
                                                                 // Extension(peut envoyer audio,video...)
        MimeMessageHelper helper = new MimeMessageHelper(message, true);// creation obejtpour faciltet la construction
                                                                        // message
        helper.setTo(to);
        helper.setSubject(subject);
        helper.setText(text, true); // true indique que le texte est au format HTML
        javaMailSender.send(message);
    }

    public void sendPdfByEmail(String toEmail, byte[] pdfBlob) throws MessagingException {
        jakarta.mail.internet.MimeMessage message = javaMailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        helper.setFrom(fromEmail);
        helper.setTo(toEmail);
        helper.setSubject("Subject: PDF Attachment");
        helper.setText("indro ny ezaka ny zanakao.");

        DataSource dataSource = new ByteArrayDataSource(pdfBlob, "application/pdf");
        helper.addAttachment("document.pdf", dataSource); // ajout pdf tant que piece
        javaMailSender.send(message);
    }
}
