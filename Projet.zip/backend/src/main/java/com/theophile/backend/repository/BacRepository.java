package com.theophile.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.theophile.backend.model.Bac;

@Repository
public interface BacRepository extends JpaRepository<Bac, Long> {

    // Compter les bacs de type mobile
    long countByTypeBac(String typeBac);

}
