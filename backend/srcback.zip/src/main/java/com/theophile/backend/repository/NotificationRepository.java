package com.theophile.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.theophile.backend.model.Notification;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {
    // Vous pouvez ajouter d'autres méthodes de requête si nécessaire
}
